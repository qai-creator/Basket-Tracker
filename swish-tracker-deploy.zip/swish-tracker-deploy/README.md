# Swish Tracker

This is a static mobile web app. It needs HTTPS for iPhone camera access.

## Easiest deployment
1. Go to Netlify Drop: https://app.netlify.com/drop
2. Sign in if Netlify asks.
3. Drag the entire `swish-tracker-deploy` folder onto the page.
4. Open the generated `https://...netlify.app` address on your iPhone.
5. Tap Start Camera and allow camera access.

The app stores shot/session data locally in the browser.

## Camera setup
For best detection:
- Use the rear camera.
- Keep the hoop visible.
- Tap "Set Hoop" and tap the centre of the rim.
- Start a session.
- Manual Make/Swish/Miss buttons remain available.

Note: the current automatic detection is a prototype. It detects the basketball and creates shot suggestions; make/swish classification still needs refinement and should be manually corrected when necessary.
